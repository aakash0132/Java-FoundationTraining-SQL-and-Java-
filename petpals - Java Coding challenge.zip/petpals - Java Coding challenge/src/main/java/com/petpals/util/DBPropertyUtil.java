package com.petpals.util;

public class DBPropertyUtil {
    public static String getConnectionString() {
        // Hardcoded connection string
        return "jdbc:mysql://localhost:3306/petpals?user=root&password=iamroot@007";
    }
}